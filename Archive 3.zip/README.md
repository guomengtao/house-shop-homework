# house-shop-homework

[Edit in StackBlitz next generation editor ⚡️](https://stackblitz.com/~/github.com/guomengtao/house-shop-homework)