# 优生活 - 房源租赁平台

## 项目版本
- **版本**: 1.1.0
- **最后更新**: 2024-12-24

## 主要更新
### 样式优化
- 使用 Less CSS 重构样式，提高代码可维护性
- 引入全局变量和混合器
- 优化响应式设计
- 增强交互动画和过渡效果

### 功能特点
- 响应式房源展示
- 动态图片轮播
- 交互式搜索功能
- 移动端适配
- 平滑的用户交互动画

## 技术栈
- HTML5
- Less CSS
- 原生JavaScript

## 项目结构
```
house-shop-homework/
│
├── index.html          # 主页
├── rental-list.html    # 租房列表页
├── house-detail.html   # 房源详情页
│
├── styles.less         # Less 样式源文件
├── styles.css          # 编译后的 CSS
│
└── images/             # 图片资源目录
```

## 开发环境
- Node.js
- Less CSS 编译器

## 如何运行
1. 克隆仓库
2. 安装 Less: `npm install -g less`
3. 编译 Less: `lessc styles.less styles.css`
4. 直接在浏览器打开 `index.html`

## 未来计划
- 添加更多交互特性
- 优化性能
- 扩展响应式设计

## 许可证
MIT License